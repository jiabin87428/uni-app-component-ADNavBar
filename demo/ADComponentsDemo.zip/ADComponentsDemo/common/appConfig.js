// 底部菜单栏高度
var TabbarHeight = 130;

export default {
	TabbarHeight
}